INSERT INTO application (
    seq,
    app_id,
    maxkb_id,
    name,
    icon,
    api_type,
    base_api,
    redirect_link,
    token,
    category,
    `desc`,
    prologue,
    enabled
) VALUES (
    3022,
    uuid(),
    NULL,
    '影视声音创作与数字技术',
    11,
    'dify/chatflow',
    'http://10.119.14.166/v1/',
    NULL,
    'app-EWokr4LKG0VczDlTVHAnKn6k',
    'AI 课程/AI+课程/影视声音创作与数字技术/AI数学推理助手',
    '授课教师：花晖',
    '欢迎体验～我是你的AI数学推理助手🔹
- 如何证明一个数列的收敛性并求其极限？
- 在解几何问题时，如何通过构造辅助线找到突破口？
- 如何用归纳法证明一个数学命题对所有自然数成立？
- 在概率问题中，如何正确运用条件概率公式？
- 如何通过反证法解决一个复杂的逻辑命题？
- 在微积分中，如何判断一个函数的可导性并求导？
- 如何用矩阵运算解决线性方程组的推理问题？
- 在数论中，如何推理一个数的素性并分解其因子？',
    1
);